OSA LaTeX templates
March 6, 2007 revisions

For use with 

Applied Optics (AO)
Journal of the Optical Society of America A (JOSA A)
Journal of the Optical Society of America B (JOSA B)
Optics Letters (OL)
Journal of Optical Networking (JON)



1. osajnl2.sty (new style file, replaces osajnl.sty)

2. ol2.sty (new style file, replaces ol.sty)

3. osajnl2.rtx (new REVTeX style file, replaces osajnl.rtx)

3. OSAstyle.tex: style guide & template for all but OL and OpEx

4. OSAtemp.tex: template for all but OL and OpEx

5. OSA-revtex-temp.tex: template with sample REVTeX feature to automate author/affiliation block

6. OLpagelength.sty: template for two-column OL format

7. osajnl.bst: BibTeX style file for OSA journals

8. ol.bst: BibTeX style file for OL
